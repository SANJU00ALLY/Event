document.addEventListener('DOMContentLoaded', function() {
    // Parse gallery XML data
    const galleryXml = document.getElementById('gallery-data').textContent;
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(galleryXml, "text/xml");
    const galleryItems = xmlDoc.getElementsByTagName("item");
    const galleryTrack = document.getElementById('gallery-track');
    
    // Create gallery items from XML data
    for (let i = 0; i < galleryItems.length; i++) {
        const item = galleryItems[i];
        const image = item.getElementsByTagName("image")[0].textContent;
        const caption = item.getElementsByTagName("caption")[0].textContent;
        
        const galleryItem = document.createElement('div');
        galleryItem.className = 'gallery-item';
        galleryItem.innerHTML = `
            <img src="${image}" alt="${caption}">
            <div class="gallery-caption">${caption}</div>
        `;
        
        galleryItem.addEventListener('click', function() {
            openFullscreen(image, caption);
        });
        
        galleryTrack.appendChild(galleryItem);
    }
    
    // Make gallery draggable
    let isDown = false;
    let startX;
    let scrollLeft;
    const galleryContainer = document.querySelector('.gallery-container');
    
    galleryContainer.addEventListener('mousedown', (e) => {
        isDown = true;
        startX = e.pageX - galleryContainer.offsetLeft;
        scrollLeft = galleryTrack.scrollLeft;
        galleryTrack.style.cursor = 'grabbing';
    });
    
    galleryContainer.addEventListener('mouseleave', () => {
        isDown = false;
        galleryTrack.style.cursor = 'grab';
    });
    
    galleryContainer.addEventListener('mouseup', () => {
        isDown = false;
        galleryTrack.style.cursor = 'grab';
    });
    
    galleryContainer.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - galleryContainer.offsetLeft;
        const walk = (x - startX) * 2;
        galleryTrack.scrollLeft = scrollLeft - walk;
    });
    
    // Fullscreen view
    function openFullscreen(imageSrc, caption) {
        const overlay = document.createElement('div');
        overlay.className = 'gallery-overlay';
        overlay.innerHTML = `
            <img src="${imageSrc}" alt="${caption}">
            <div class="close-gallery"><i class="ph ph-x"></i></div>
        `;
        
        document.body.appendChild(overlay);
        
        setTimeout(() => {
            overlay.classList.add('active');
        }, 10);

        const closeButton = overlay.querySelector('.close-gallery');
    
    // Add the event listener to the close button.
    closeButton.addEventListener('click', () => {
        // Remove the active class to trigger the transition out.
        overlay.classList.remove('active');
        
        // Wait for the transition to finish before removing the element.
        setTimeout(() => {
            overlay.remove();
        }, 300); 
    });

    //  Closing the overlay with the ESC key.
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            overlay.classList.remove('active');
            setTimeout(() => {
                overlay.remove();
            }, 300);
        }
    }, { once: true }); 
        
    }
    
    // Animate gallery items on scroll
    const galleryObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });
    
    document.querySelectorAll('.gallery-item').forEach(item => {
        galleryObserver.observe(item);
    });
});