document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contact-form');
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Simple validation
        const name = document.getElementById('contact-name');
        const email = document.getElementById('contact-email');
        const message = document.getElementById('contact-message');
        
        if (!name.value.trim()) {
            alert('Please enter your name');
            return;
        }
        
        if (!email.value.trim()) {
            alert('Please enter your email');
            return;
        }
        
        if (!message.value.trim()) {
            alert('Please enter your message');
            return;
        }
        
        // Form submission would go here
        alert('Thank you for your message! We will get back to you soon.');
        contactForm.reset();
    });
});