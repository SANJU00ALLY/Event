// Intersection Observer for scroll animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const animateOnScroll = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe all elements with the 'animate' class
document.querySelectorAll('.session-block, .about-image, .about-content, .skill-item, .social-links, .contact-form, .testimonial-card, .gallery-item').forEach(el => {
    animateOnScroll.observe(el);
});

// Hero title animation
const heroTitle = document.querySelector('.hero-title');
if (heroTitle) {
    heroTitle.style.opacity = '0';
    heroTitle.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        heroTitle.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        heroTitle.style.opacity = '1';
        heroTitle.style.transform = 'translateY(0)';
    }, 300);
}

// Hero subtitle animation
const heroSubtitle = document.querySelector('.hero-subtitle');
if (heroSubtitle) {
    heroSubtitle.style.opacity = '0';
    heroSubtitle.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        heroSubtitle.style.transition = 'opacity 0.6s ease 0.2s, transform 0.6s ease 0.2s';
        heroSubtitle.style.opacity = '1';
        heroSubtitle.style.transform = 'translateY(0)';
    }, 300);
}

// Hero CTA animation
const heroCta = document.querySelector('.hero-cta');
if (heroCta) {
    heroCta.style.opacity = '0';
    heroCta.style.transform = 'translateY(20px)';
    
    setTimeout(() => {
        heroCta.style.transition = 'opacity 0.6s ease 0.4s, transform 0.6s ease 0.4s';
        heroCta.style.opacity = '1';
        heroCta.style.transform = 'translateY(0)';
    }, 300);
}

document.querySelectorAll('.session-block').forEach(el => {
    animateOnScroll.observe(el);
});