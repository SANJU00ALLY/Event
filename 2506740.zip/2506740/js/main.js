document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    console.log('Lunara Conference website initialized');
    
    
});