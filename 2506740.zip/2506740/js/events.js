document.addEventListener('DOMContentLoaded', function() {
    const eventsContainer = document.getElementById('events-container'); // Define container
    if (!eventsContainer) {
        console.error('Events container not found');
        return;
    }

    fetch('/data/events-details.xml')
        .then(response => response.text())
        .then(data => {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(data, 'text/xml');
            const events = xmlDoc.getElementsByTagName('event');

            for (let event of events) {
                const id=event.getAttribute('id');
                const title = event.getElementsByTagName('title')[0].textContent;
                const date = new Date(event.getElementsByTagName('date')[0].textContent);
                const location = event.getElementsByTagName('location')[0].textContent;
                const price = event.getElementsByTagName('price')[0].textContent;
                const description = event.getElementsByTagName('overview')[0].textContent; // Use overview instead of description
                const image = event.getElementsByTagName('image')[0].textContent;

                const formattedDate = date.toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                });

                const eventCard = document.createElement('div');
                eventCard.className = 'event-card';
                eventCard.innerHTML = `
                    <div class="event-image">
                        <img src="${image}" alt="${title}">
                    </div>
                    <div class="event-content">
                        <h3>${title}</h3>
                        <div class="event-meta">
                            <span class="event-date">${formattedDate}</span>
                            <span class="event-location">${location}</span>
                        </div>
                        <div class="event-meta">
                            <span class="event-price">LKR ${parseInt(price).toLocaleString()}</span>
                        </div>
                        <p class="event-description">${description}</p>
                        <a href="learn-more.html?id=${id}" class="event-link">Learn More <i class="ph ph-arrow-right"></i></a>
                    </div>
                `;

                eventsContainer.appendChild(eventCard);
            }
        })
        .catch(error => console.error('Error reading XML:', error));
});