document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const eventId = urlParams.get('id'); // Uncomment to use URL parameter
    //const eventId = 'quantum-leap';
    console.log(eventId);

    if (!eventId) {
        window.location.href = '../index.html';
        return;
    }

    fetch('/data/events-details.xml')
    .then(response => response.text())
    .then(data => {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(data, 'text/xml');
    const events = xmlDoc.getElementsByTagName('event');

    for (let event of events) {
      const id = event.getAttribute('id');
      //console.log(typeof(id));
      const title = event.getElementsByTagName('title')[0].textContent;
      const date = event.getElementsByTagName('date')[0].textContent;
      const location = event.getElementsByTagName('location')[0].textContent;
      const price = event.getElementsByTagName('price')[0].textContent;
      const image = event.getElementsByTagName('image')[0].textContent;
      const overview = event.getElementsByTagName('overview')[0].textContent;
      const whyMatters = event.getElementsByTagName('why-matters')[0].textContent;
      const professionals = Array.from(event.getElementsByTagName('professional')).map(prof => prof.textContent);

      //console.log({ id, title, date, location, price, image, overview, whyMatters, professionals });
      if(id===eventId){
        //console.log("found");
        const imageDiv=document.getElementById("event-image");
        imageDiv.innerHTML=`
            <img src="${image}" alt="ai-summit">
        `
        document.getElementById('event-title').textContent=title;
        document.getElementById('event-date').textContent=date;
        document.getElementById('event-location').textContent=location;
        document.getElementById('event-price').textContent="Rs."+ price+".00";
        document.getElementById('event-overview').textContent=overview;
        document.getElementById('event-why-matters').textContent=whyMatters;
        const ul = document.getElementById('professionals-list');
        professionals.forEach(item => {
            const li = document.createElement('li');
            console.log(item);
            li.textContent = item;
            ul.appendChild(li);
        });
        console.log(professionals);
      }
    }
  })
  .catch(error => console.error('Error reading XML:', error));
});