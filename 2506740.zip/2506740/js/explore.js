document.addEventListener('DOMContentLoaded', function() {
    // Parse XML data
    const sessionsXml = document.getElementById('sessions-data').textContent;
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(sessionsXml, "text/xml");
    const sessions = xmlDoc.getElementsByTagName("session");
    const exploreContainer = document.getElementById('explore-container');
    
    // Create session blocks
    for (let i = 0; i < sessions.length; i++) {
        const session = sessions[i];
        const title = session.getElementsByTagName("title")[0].textContent;
        const date = new Date(session.getElementsByTagName("date")[0].textContent);
        const location = session.getElementsByTagName("location")[0].textContent;
        const price = session.getElementsByTagName("price")[0].textContent;
        const capacity = session.getElementsByTagName("capacity")[0].textContent;
        const description = session.getElementsByTagName("description")[0].textContent;
        const image = session.getElementsByTagName("image")[0].textContent;
        
        const formattedDate = date.toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
        
        const sessionBlock = document.createElement('div');
        sessionBlock.className = 'session-block';
        sessionBlock.innerHTML = `
            <div class="session-image">
                <img src="${image}" alt="${title}" loading="lazy">
            </div>
            <div class="session-content">
                <h3>${title}</h3>
                <div class="session-meta">
                    <span><i class="ph ph-calendar"></i> ${formattedDate}</span>
                    <span><i class="ph ph-map-pin"></i> ${location}</span>
                    <span><i class="ph ph-users"></i> ${capacity} seats</span>
                </div>
                <div class="session-price">LKR ${parseInt(price).toLocaleString()} <span>per person</span></div>
                <p class="session-description">${description}</p>
                <a href="#register" class="session-link">Book Now <i class="ph ph-arrow-right"></i></a>
            </div>
        `;
        
        exploreContainer.appendChild(sessionBlock);
    }
    
    // Initialize filters
    setupFilters();
    
    // Animate on scroll
    const sessionBlocks = document.querySelectorAll('.session-block');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });
    
    sessionBlocks.forEach(block => observer.observe(block));
});

function setupFilters() {
    const dateFilter = document.getElementById('date-filter');
    const locationFilter = document.getElementById('location-filter');
    const capacityFilter = document.getElementById('capacity-filter');
    const noEventsMessage = document.getElementById('no-events-message');
    
    function filterSessions() {
        const dateValue = dateFilter.value;
        const locationValue = locationFilter.value;
        const capacityValue = capacityFilter.value;
        
        document.querySelectorAll('.session-block').forEach(block => {
            const date = block.querySelector('.session-meta span:nth-child(1)').textContent;
            const location = block.querySelector('.session-meta span:nth-child(2)').textContent.toLowerCase();
            const capacity = parseInt(block.querySelector('.session-meta span:nth-child(3)').textContent);
            
            const dateMatch = dateValue === 'all' || date.includes(dateValue.substring(5));
            const locationMatch = locationValue === 'all' || location.includes(locationValue);
            const capacityMatch = capacityValue === 'all' || 
                (capacityValue === 'small' && capacity <= 100) ||
                (capacityValue === 'medium' && capacity > 100 && capacity <= 500) ||
                (capacityValue === 'large' && capacity > 500);
            
            block.style.display = (dateMatch && locationMatch && capacityMatch) ? 'flex' : 'none';
        });
    }
    
    dateFilter.addEventListener('change', filterSessions);
    locationFilter.addEventListener('change', filterSessions);
    capacityFilter.addEventListener('change', filterSessions);
}