document.addEventListener('DOMContentLoaded', function() {
    // Parse testimonials XML data
    const testimonialsXml = document.getElementById('testimonials-data').textContent;
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(testimonialsXml, "text/xml");
    const testimonials = xmlDoc.getElementsByTagName("testimonial");
    const testimonialsSlider = document.getElementById('testimonials-slider');
    
    // Create testimonial cards from XML data
    for (let i = 0; i < testimonials.length; i++) {
        const testimonial = testimonials[i];
        const name = testimonial.getElementsByTagName("name")[0].textContent;
        const title = testimonial.getElementsByTagName("title")[0].textContent;
        const review = testimonial.getElementsByTagName("review")[0].textContent;
        const rating = testimonial.getElementsByTagName("rating")[0].textContent;
        
        const testimonialCard = document.createElement('div');
        testimonialCard.className = 'testimonial-card';
        testimonialCard.innerHTML = `
            <div class="rating">
                ${'<i class="ph ph-star-fill"></i>'.repeat(rating)}
            </div>
            <p class="review">"${review}"</p>
            <div class="author">
                <div class="author-info">
                    <div class="author-name">${name}</div>
                    <div class="author-title">${title}</div>
                </div>
            </div>
        `;
        
        testimonialsSlider.appendChild(testimonialCard);
    }
    
    // Testimonial slider functionality
    const prevBtn = document.getElementById('prev-testimonial');
    const nextBtn = document.getElementById('next-testimonial');
    const slider = document.querySelector('.testimonials-slider');
    const cards = document.querySelectorAll('.testimonial-card');
    let currentIndex = 0;
    
    function updateSlider() {
        cards.forEach((card, index) => {
            if (index === currentIndex) {
                card.classList.add('active');
            } else {
                card.classList.remove('active');
            }
        });
        
        const cardWidth = cards[0].offsetWidth + 30; // including gap
        slider.scrollTo({
            left: currentIndex * cardWidth,
            behavior: 'smooth'
        });
    }
    
    prevBtn.addEventListener('click', () => {
        currentIndex = (currentIndex > 0) ? currentIndex - 1 : cards.length - 1;
        updateSlider();
    });
    
    nextBtn.addEventListener('click', () => {
        currentIndex = (currentIndex < cards.length - 1) ? currentIndex + 1 : 0;
        updateSlider();
    });
    
    // Set first testimonial as active initially
    if (cards.length > 0) {
        cards[0].classList.add('active');
    }
    
    // Auto-advance testimonials
    setInterval(() => {
        currentIndex = (currentIndex < cards.length - 1) ? currentIndex + 1 : 0;
        updateSlider();
    }, 5000);
    
    // Animate testimonials on scroll
    const testimonialObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });
    
    document.querySelectorAll('.testimonial-card').forEach(card => {
        testimonialObserver.observe(card);
    });
});