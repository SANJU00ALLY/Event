document.addEventListener('DOMContentLoaded', function() {
    const sessionsXml = document.getElementById('sessions-data').textContent;
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(sessionsXml, "text/xml");
    const sessions = xmlDoc.getElementsByTagName("session");
    const eventDropdown = document.getElementById('event');
    
    // Clear existing options except the first one
    while (eventDropdown.options.length > 1) {
        eventDropdown.remove(1);
    }
    
    // Add sessions as options
    for (let i = 0; i < sessions.length; i++) {
        const session = sessions[i];
        const title = session.getElementsByTagName("title")[0].textContent;
        const price = session.getElementsByTagName("price")[0].textContent;
        
        const option = document.createElement('option');
        option.value = title.toLowerCase().replace(/\s+/g, '-');
        option.textContent = `${title} (LKR ${parseInt(price).toLocaleString()})`;
        eventDropdown.appendChild(option);
    }
    
    const registrationForm = document.getElementById('registration-form');
    const successMessage = document.getElementById('success-message');
    
    // Initially hide success message
    successMessage.style.display = 'none';
    
    // Form validation
    registrationForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Reset error messages
        document.querySelectorAll('.error-message').forEach(el => {
            el.textContent = '';
        });
        
        // Validate fields
        let isValid = true;
        
        // Full name validation
        const fullName = document.getElementById('full-name');
        if (!fullName.value.trim()) {
            document.getElementById('name-error').textContent = 'Full name is required';
            isValid = false;
        } else if (fullName.value.trim().length < 3) {
            document.getElementById('name-error').textContent = 'Name must be at least 3 characters';
            isValid = false;
        }
        
        // Email validation
        const email = document.getElementById('email');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email.value.trim()) {
            document.getElementById('email-error').textContent = 'Email is required';
            isValid = false;
        } else if (!emailRegex.test(email.value)) {
            document.getElementById('email-error').textContent = 'Please enter a valid email';
            isValid = false;
        }

        // Phone number validation
        const phone = document.getElementById('phone');
        const phoneRegex = /^0\d{9}$/; // Starts with 0, followed by exactly 9 digits

        // Clear previous error message
        document.getElementById('phone-error').textContent = '';

        if (!phone.value.trim()) {
            document.getElementById('phone-error').textContent = 'Phone number is required';
            isValid = false;
        } else if (!phoneRegex.test(phone.value.trim())) {
            document.getElementById('phone-error').textContent = 'Please enter a valid 10-digit phone number starting with 0';
            isValid = false;
        }
        
        // Event selection validation
        const event = document.getElementById('event');
        if (!event.value) {
            document.getElementById('event-error').textContent = 'Please select an event';
            isValid = false;
        }
        
        // Terms checkbox validation
        const terms = document.getElementById('terms');
        if (!terms.checked) {
            alert('You must agree to the terms and conditions');
            isValid = false;
        }
        
        // If form is valid, show success message
        if (isValid) {
            registrationForm.style.display = 'none';
            successMessage.style.display = 'block';
            
            // Reset form after 5 seconds
            setTimeout(() => {
                registrationForm.reset();
                registrationForm.style.display = 'block';
                successMessage.style.display = 'none';
            }, 5000);
        }
    });
    
    // Animate form inputs on scroll
    const formObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });
    
    document.querySelectorAll('.form-group').forEach((group, index) => {
        group.style.transitionDelay = `${index * 0.1}s`;
        formObserver.observe(group);
    });
});